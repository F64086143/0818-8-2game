import pygame
import math
import os
import random
from settings import BASE3, PATH3, RE_PATH3_1, RE_PATH3_2,IMAGE_PATH
from color_settings import *


pygame.init()
ENEMY_IMAGE = pygame.image.load(os.path.join(IMAGE_PATH, "en01.png"))
ENEMY2_IMAGE = pygame.image.load(os.path.join(IMAGE_PATH, "en02.png"))
ENEMY3_IMAGE = pygame.image.load(os.path.join(IMAGE_PATH, "en03.png"))
ENEMY4_IMAGE = pygame.image.load(os.path.join(IMAGE_PATH, "en04.png"))
photo_list = [ENEMY_IMAGE, ENEMY2_IMAGE, ENEMY3_IMAGE, ENEMY4_IMAGE]
size_list = [50, 75, 100]

num_enemy = 0

class Enemy:
    def __init__(self):
        global num_enemy
        self.path_index = 0
        if num_enemy % 3 == 0:  # 順向路徑
            self.path = PATH3
        elif num_enemy % 3 == 1:  #逆向路徑
            self.path = RE_PATH3_1
        elif num_enemy % 3 == 2:
            self.path = RE_PATH3_2
        self.move_count = 0
        self.stride = 1
        self.size = random.choices(size_list)[0]
        self.image = pygame.transform.scale((random.choices(photo_list)[0]), (self.size, self.size))
        self.rect = self.image.get_rect()
        self.rect.center = self.path[self.path_index]
        self.move_count = 0
        self.health = self.size * 0.5
        self.max_health = self.size * 0.5
        self.sound = pygame.mixer.Sound("./sound/swish1.mp3")
        # 新增項目
        self.damage = [2, 10, 15, 20]
        self.selected_enemy = None

    def move(self):
        x1, y1 = self.path[self.path_index]
        x2, y2 = self.path[self.path_index + 1]
        distance = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        max_count = int(distance / self.stride)
        # compute the unit vector
        unit_vector_x = (x2 - x1) / distance
        unit_vector_y = (y2 - y1) / distance
        # compute the movement
        delta_x = unit_vector_x * self.stride * self.move_count
        delta_y = unit_vector_y * self.stride * self.move_count
        # update the position and counter
        if self.move_count <= max_count:
            self.rect.center = (x1 + delta_x, y1 + delta_y)
            self.move_count += 1
        else:
            self.move_count = 0
            self.path_index += 1
            self.rect.center = self.path[self.path_index]


    # 新增函式
    def enemy_clicked(self, x, y):
        """
        Return Whether the enemy is clicked
        (This method is call in enemy_get_click() method in class EnemyGroup)
        :param x: mouse x
        :param y: mouse y
        :return: bool
        """
        # 判斷滑鼠點擊之座標是否在 enemy's image 中，並回傳
        return True if self.rect.collidepoint(x, y) else False

    # 新增函式
    def enemy_attack(self):
        """
        Attack the enemy
        :return: None
        """
        self.sound.set_volume(0.1)
        self.sound.play()
        from game3.user_request3 import level
        self.health -= self.damage[level]

class EnemyGroup:
    def __init__(self):
        self.campaign_count = 0
        self.campaign_max_count = 50   # (unit: frame)
        self.__reserved_members = []
        self.__expedition = []

        global num_enemy
        for i in range(100):
            self.__reserved_members.append(Enemy())
            num_enemy = i


    def advance(self, model):
        """Bonus.2"""
        # use model.hp and model.money to access the hp and money information
        self.campaign()
        for en in self.__expedition:
            en.move()
            if en.health <= 0:
                self.retreat(en)
                if en.size == 50:
                    model.money += 100
                elif en.size == 75:
                    model.money += 200
                else:
                    model.money += 300 # 若一隻 enemy 被殺死，則加錢 15

            # delete the object when it reach the base
            if BASE3.collidepoint(en.rect.centerx, en.rect.centery):
                self.retreat(en)
                model.hp -= 1  # 若一隻 enemy 攻擊到工科系館，則 hp - 1
            # 若 hp 變成 0，則遊戲結束
                # if model.hp = 0:
                # 遊戲結束
            # 新增判斷式 (attack or not)
            if en.selected_enemy == en:
                en.enemy_attack()
                # en.selected_enemy = None


    def campaign(self):
        """
        Enemy go on an expedition.
        """
        if self.campaign_count > self.campaign_max_count and self.__reserved_members:
            self.__expedition.append(self.__reserved_members.pop())
            self.campaign_count = 0
        else:
            self.campaign_count += 1

    def get(self):
        """
        Get the enemy list
        """
        return self.__expedition

    def is_empty(self):
        """
        Return whether the enemy is empty (so that we can move on to next wave)
        """
        return False if self.__reserved_members or self.__expedition else True

    def retreat(self, enemy):
        """
        Remove the enemy from the expedition
        :param enemy: class Enemy()
        :return: None
        """
        self.__expedition.remove(enemy)





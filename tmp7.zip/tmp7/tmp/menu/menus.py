import pygame
import os
from settings import IMAGE_PATH
pygame.init()
MENU_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "list.png")), (400, 300))

# 第一關按鈕
MASK_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "mask.png")), (100, 100))
HAZMAT_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "hazmat.png")), (100, 100))
TESTING_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "testing.png")), (100, 100))
# 第二關
RING_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "ring.png")), (100, 100))
GLASSES_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "sunglasses.png")), (100, 100))
TAXI_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "taxi.png")), (100, 100))
# 第三關
PASSPORT_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "passport.png")), (100, 100))
RESULT_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "result.png")), (100, 100))
WEAR_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "wear.png")), (100, 100))

muse_button_image = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH,"muse.png")), (80, 80))
music_button_image = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH,"sound.png")), (80, 80))


class Button:
    def __init__(self, image, name: str, x: int, y: int):
        self.image = image
        self.name = name
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def clicked(self, x, y):
        return True if self.rect.collidepoint(x, y) else False

    @property
    def response(self):
        return self.name


class Menu:
    def __init__(self, x: int, y: int):
        self.image = MENU_IMAGE
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self._buttons = []

    @property
    def buttons(self):
        return self._buttons


# 第一關
class BuildMenu(Menu):
    def __init__(self, x, y):
        super().__init__(x, y)
        self._buttons = [Button(MASK_BTN_IMAGE, "mask", self.rect.centerx +300, self.rect.centery - 300),
                         Button(HAZMAT_BTN_IMAGE, "hazmat", self.rect.centerx +450, self.rect.centery - 300),
                         Button(TESTING_BTN_IMAGE, "testing", self.rect.centerx +600, self.rect.centery - 300),
                         ]


# 第二關
class BuildMenu2(Menu):
    def __init__(self, x, y):
        super().__init__(x, y)
        self._buttons = [Button(RING_BTN_IMAGE, "ring", self.rect.centerx + 300, self.rect.centery - 300),
                         Button(GLASSES_BTN_IMAGE, "glasses", self.rect.centerx + 450, self.rect.centery - 300),
                         Button(TAXI_BTN_IMAGE, "taxi", self.rect.centerx + 600, self.rect.centery - 300),
                         ]


# 第三關
class BuildMenu3(Menu):
    def __init__(self, x, y):
        super().__init__(x, y)
        self._buttons = [Button(PASSPORT_BTN_IMAGE, "passport", self.rect.centerx +300, self.rect.centery - 300),
                         Button(RESULT_BTN_IMAGE, "result", self.rect.centerx +450, self.rect.centery - 300),
                         Button(WEAR_BTN_IMAGE, "wear", self.rect.centerx +600, self.rect.centery - 300),
                         ]


class MainMenu:
    def __init__(self):
        self._buttons = [Button(music_button_image, "music", 200, 10),
                         Button(muse_button_image, "mute", 280, 10),]

    @property
    def buttons(self):
        return self._buttons
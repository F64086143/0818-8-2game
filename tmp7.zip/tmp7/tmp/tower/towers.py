from tower.attack_strategy import AOE, SingleAttack, Snipe
import os
import pygame
from settings import IMAGE_PATH

PLOT_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "basket.png")), (90, 90))
# 第一關
MASK_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "mask.png")), (100, 100))
HAZMAT_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "hazmat.png")), (100, 100))
TESTING_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "testing.png")), (100, 100))
# 第二關
RING_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "ring.png")), (100, 100))
GLASSES_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "sunglasses.png")), (100, 100))
TAXI_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "taxi.png")), (100, 100))
# 第三關
PASSPORT_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "passport.png")), (100, 100))
RESULT_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "result.png")), (100, 100))
WEAR_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join(IMAGE_PATH, "wear.png")), (100, 100))

# 籃子
class Vacancy:
    def __init__(self, x, y):
        self.image = PLOT_IMAGE
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def clicked(self, x: int, y: int) -> bool:
        return True if self.rect.collidepoint(x, y) else False


# 升級籃子中的裝備
class Tower:
    """ super class of towers """
    def __init__(self, x: int, y: int, attack_strategy, image):
        self.image = image  # image of the tower
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)  # center of the tower
        self._damage = 10   # tower damage
        self.attack_strategy = attack_strategy  # chose an attack strategy (AOE, single attack ....)
        self.value = 100

    @classmethod
    def Mask(cls, x, y):
        mask = cls(x, y, SingleAttack(), MASK_BTN_IMAGE)
        mask.value = 150
        return mask
    @classmethod
    def Hazmat(cls, x, y):
        hazmat = cls(x, y, AOE(), HAZMAT_BTN_IMAGE)
        hazmat.value = 350
        return hazmat

    @classmethod
    def Testing(cls, x, y):
        testing = cls(x, y, Snipe(), TESTING_BTN_IMAGE)
        testing.value = 600
        return testing

    def get_cost(self):
        return self.value

    @property
    def damage(self):
        return self._damage[self.level]

    def clicked(self, x: int, y: int) -> bool:
        """
        :param x: mouse pos x
        :param y: mouse pos y
        :return: bool
        """
        return True if self.rect.collidepoint(x, y) else False

class Tower2:
    """ super class of towers """
    def __init__(self, x: int, y: int, attack_strategy, image):
        self.image = image  # image of the tower
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)  # center of the tower
        self._damage = 10   # tower damage
        self.attack_strategy = attack_strategy  # chose an attack strategy (AOE, single attack ....)
        self.value = 100

    @classmethod
    def Ring(cls, x, y):
        ring = cls(x, y, SingleAttack(), RING_BTN_IMAGE)
        ring.value = 200
        return ring
    @classmethod
    def Glasses(cls, x, y):
        glasses = cls(x, y, AOE(), GLASSES_BTN_IMAGE)
        glasses.value = 500
        return glasses

    @classmethod
    def Taxi(cls, x, y):
        taxi = cls(x, y, Snipe(), TAXI_BTN_IMAGE)
        taxi.value = 1000
        return taxi

    def get_cost(self):
        return self.value

    @property
    def damage(self):
        return self._damage[self.level]

    def clicked(self, x: int, y: int) -> bool:
        """
        :param x: mouse pos x
        :param y: mouse pos y
        :return: bool
        """
        return True if self.rect.collidepoint(x, y) else False

class Tower3:
    """ super class of towers """
    def __init__(self, x: int, y: int, attack_strategy, image):
        self.image = image  # image of the tower
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)  # center of the tower
        self._damage = 10   # tower damage
        self.attack_strategy = attack_strategy  # chose an attack strategy (AOE, single attack ....)
        self.value = 100

    @classmethod
    def Passport(cls, x, y):
        passport = cls(x, y, SingleAttack(), PASSPORT_BTN_IMAGE)
        passport.value = 400
        return passport
    @classmethod
    def Result(cls, x, y):
        result = cls(x, y, AOE(), RESULT_BTN_IMAGE)
        result.value = 800
        return result

    @classmethod
    def Wear(cls, x, y):
        wear = cls(x, y, Snipe(), WEAR_BTN_IMAGE)
        wear.value = 1400
        return wear

    def get_cost(self):
        return self.value

    @property
    def damage(self):
        return self._damage[self.level]

    def clicked(self, x: int, y: int) -> bool:
        """
        :param x: mouse pos x
        :param y: mouse pos y
        :return: bool
        """
        return True if self.rect.collidepoint(x, y) else False

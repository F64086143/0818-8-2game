import pygame
from game3.controller3 import GameControl3
from game3.model3 import GameModel3
from game3.view3 import GameView3
from settings import FPS


class Game3:
    def play_music3(self):
        pygame.mixer.music.load("./sound/關卡.mp3")
        pygame.mixer.music.set_volume(0.1)
        pygame.mixer.music.play(-1)
    def run3(self):
        # initialization
        pygame.init()
        pygame.mixer.init()
        self.play_music3()
        game_model = GameModel3()  # core of the game (database, game logic...)
        game_view = GameView3()  # render everything
        game_control = GameControl3(game_model, game_view)  # deal with the game flow and user request
        quit_game = False
        while not quit_game:
            pygame.time.Clock().tick(FPS)  # control the frame rate
            game_control.receive_user_input()  # receive user input
            game_control.update_model()  # update the model
            game_control.update_view()  # update the view
            pygame.display.update()
            quit_game = game_control.quit_game

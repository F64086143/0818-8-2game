import pygame
from settings import WIN_WIDTH, WIN_HEIGHT, HP_IMAGE, HP_GRAY_IMAGE, BACKGROUND3_IMAGE,BOY_IMAGE,\
    MENU_IMAGE,ALCOHOL_OP_IMAGE,ALCOHOL_CL_IMAGE,PASSPORT_IMAGE ,RESULT_IMAGE ,WEAR_IMAGE,\
    SOUND_IMAGE,MUTE_IMAGE,JAIL_IMAGE
from color_settings import *
import math
import sys
from pygame.locals import *
from end import end1
import time

class GameView3:
    def __init__(self):
        self.win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
        self.font = pygame.font.SysFont("comicsans", 30)
        pygame.display.set_caption("Covid-19 Defense Game-level3")

    def draw_bg(self):
        self.win.blit(BACKGROUND3_IMAGE, (0, 0))
        self.win.blit(BOY_IMAGE,(300,200))
        self.win.blit(SOUND_IMAGE, (200, 10))
        self.win.blit(MUTE_IMAGE, (280, 10))

    #def draw_map(self):
     #   self.win.blit(MAP_IMAGE, (0, 0))
        
    def draw_time(self):
        time3 = pygame.time.get_ticks()
        seconds = (40000 - time3) / 1000
        mins = str(math.floor(seconds) // 60).zfill(2)
        secs = str(math.floor(seconds) % 60).zfill(2)
        #self.font = pygame.font.Font(pygame.font.match_font('arial'), 40)
        self.font = pygame.font.SysFont(None, 40)
        text_surface = self.font.render(mins + ':' + secs, True, (0, 0, 0))
        self.win.blit(text_surface, (700, 20))  # 印出時間
        if seconds < 0:
            pygame.display.update()
            END = end1()
            END.end_run1()

    def draw_enemies(self, enemies):
        for en in enemies.get():
            self.win.blit(en.image, en.rect)
            # draw health bar
            bar_width = en.rect.w * (en.health / en.max_health)
            max_bar_width = en.rect.w
            bar_height = 5
            pygame.draw.rect(self.win, RED, [en.rect.x, en.rect.y - 10, max_bar_width, bar_height])
            pygame.draw.rect(self.win, GREEN, [en.rect.x, en.rect.y - 10, bar_width, bar_height])

    def draw_menu(self, menu):
        self.win.blit(MENU_IMAGE, (320, 85))
        text = self.font.render(f"$400", True, (0, 0, 0))
        self.win.blit(text, (340, 150))
        text = self.font.render(f"$800", True, (0, 0, 0))
        self.win.blit(text, (480, 150))
        text = self.font.render(f"$1400", True, (0, 0, 0))
        self.win.blit(text, (630, 150))
        #self.font = pygame.font.Font(pygame.font.match_font('arial'), 25)
        self.font = pygame.font.SysFont(None, 25)
        text = self.font.render(f"attack level1", True, (0, 0, 0))
        self.win.blit(text, (340, 280))
        text = self.font.render(f"attack level2", True, (0, 0, 0))
        self.win.blit(text, (480, 280))
        text = self.font.render(f"attack level3", True, (0, 0, 0))
        self.win.blit(text, (630, 280))

        for btn in menu.buttons:
            self.win.blit(btn.image, btn.rect)

    # 籃子按鈕
    def draw_plots(self, plots):
        for pt in plots:
            self.win.blit(pt.image, pt.rect)

    def draw_money(self, money: int):
        """ (Q2.1)render the money"""
        #self.font = pygame.font.Font(pygame.font.match_font('arial'), 40)
        self.font = pygame.font.SysFont(None, 40)
        text = self.font.render(f"Money: {money}", True, (0, 0, 0))
        self.win.blit(text, (5, 15))

    def draw_hp(self, lives):
        # draw_lives
        hp_rect = HP_IMAGE.get_rect()
        for i in range(10):
            self.win.blit(HP_GRAY_IMAGE, (WIN_WIDTH // 2 - hp_rect.w * (2.5 - i % 5), hp_rect.h * (i // 5)))
        for i in range(lives):
            self.win.blit(HP_IMAGE, (WIN_WIDTH // 2 - hp_rect.w * (2.5 - i % 5), hp_rect.h * (i // 5)))
        if int(lives) <= 0:
            self.win.fill([0, 0, 0])
            self.win.blit(JAIL_IMAGE, (250, 50))
            pygame.display.update()
            time.sleep(5)
            pygame.quit()
            sys.exit()

    def draw_alcohol(self, enemies):
        count = 0
        for en in enemies.get():
            # print("2.", en.selected_enemy)
            if en.selected_enemy is not None:
                count += 1
                en.selected_enemy = None
        if count != 0:
            self.win.blit(ALCOHOL_OP_IMAGE, (450, 250))
        else:
            self.win.blit(ALCOHOL_CL_IMAGE, (450, 250))

    def draw_tool(self):
        from game3.user_request3 import level
        if level == 1:
            self.win.blit(PASSPORT_IMAGE, (150, 330))
        elif level == 2:
            self.win.blit(RESULT_IMAGE, (250, 330))
        elif level == 3:
            self.win.blit(WEAR_IMAGE, (300, 240))









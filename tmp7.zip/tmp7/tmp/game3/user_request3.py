import pygame
from tower.towers import Tower3
import os
# from enemy.enemies import level
import os
from settings import SOUND_PATH
"""This module is import in model.py"""

"""
Here we demonstrate how does the Observer Pattern work
Once the subject updates, if will notify all the observer who has register the subject
"""
level = 0

class RequestSubject:
    def __init__(self, model):
        self.__observers = []
        self.model = model

    def register(self, observer):
        self.__observers.append(observer)

    def notify(self, user_request):
        for o in self.__observers:
            o.update(user_request, self.model)


class EnemyGenerator:
    def __init__(self, subject):
        subject.register(self)

    def update(self, user_request: str, model):
        """add new enemy"""
        if user_request == "start new wave":
            model.enemies.add(100)


class TowerFactory:
    def __init__(self, subject):
        subject.register(self)
        self.tower_name = ["passport", "result", "wear"]
        self.sound = pygame.mixer.Sound(os.path.join(SOUND_PATH, "coin.mp3"))
        self.sound.set_volume(0.2)

    def update(self, user_request: str, model):
        """add new tower"""
        global level
        for name in self.tower_name:
            if user_request == name:
                x, y = model.selected_plot.rect.center
                tower_dict = {"passport": Tower3.Passport(x, y), "result": Tower3.Result(x, y), "wear": Tower3.Wear(x, y)}
                new_tower = tower_dict[user_request]
                if model.money >= new_tower.get_cost():
                    if user_request == "passport":
                        level = 1
                        self.sound.play()
                    elif user_request == "result":
                        level = 2
                        self.sound.play()
                    elif user_request == "wear":
                        level = 3
                        self.sound.play()
                    model.money -= new_tower.get_cost()
                    model.selected_plot = None


class Music:
    def __init__(self, subject):
        subject.register(self)

    def update(self, user_request: str, model):
        """music on"""
        if user_request == "music":
            pygame.mixer.music.unpause()
            model.sound.play()


class Muse:
    def __init__(self, subject):
        subject.register(self)

    def update(self, user_request: str, model):
        """music off"""
        if user_request == "mute":
            pygame.mixer.music.pause()
            model.sound.play()


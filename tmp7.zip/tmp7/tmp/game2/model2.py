import pygame
import os
from tower.towers import Vacancy
from enemy.enemies2 import EnemyGroup,Enemy
from menu.menus import MainMenu,BuildMenu2
from game2.user_request2 import RequestSubject2, TowerFactory, EnemyGenerator, Muse, Music
from settings import WIN_WIDTH, WIN_HEIGHT, BACKGROUND_IMAGE,SOUND_PATH


class GameModel2:
    def __init__(self):
        # data
        self.bg_image = pygame.transform.scale(BACKGROUND_IMAGE, (WIN_WIDTH, WIN_HEIGHT))
        self.__enemies = EnemyGroup()
        self.__menu = None
        self.__main_menu = MainMenu()
        self.__plots = [Vacancy(72, 520)]
        # selected item
        self.selected_plot = None
        self.selected_tower = None
        self.selected_button = None
        self.selected_enemy = None
        # apply observer pattern
        self.subject = RequestSubject2(self)
        self.factory = TowerFactory(self.subject)
        self.generator = EnemyGenerator(self.subject)
        self.muse = Muse(self.subject)
        self.music = Music(self.subject)
        #
        self.wave = 0
        self.money = 0
        self.max_hp = 10
        self.hp = self.max_hp
        self.sound = pygame.mixer.Sound(os.path.join(SOUND_PATH, "click.mp3"))
        self.sound.set_volume(0.1)
        # 時間
        self.time = pygame.time.get_ticks()

    def user_request(self, user_request: str):
        """ add tower, sell tower, upgrade tower"""
        self.subject.notify(user_request)

    def get_request(self, events: dict) -> str:
        """get keyboard response or button response"""
        # initial
        self.selected_button = None
        # key event
        if events["keyboard key"] is not None:
            return "start new wave"
        # mouse event
        if events["mouse position"] is not None:
            x, y = events["mouse position"]
            self.select(x, y)
            if self.selected_button is not None:
                return self.selected_button.response
            return "nothing"
        return "nothing"

    def select(self, mouse_x: int, mouse_y: int) -> None:
        """change the state of whether the items are selected"""
        # if the item is clicked, select the item
            # 籃子按鈕
        for pt in self.__plots:
            if pt.clicked(mouse_x, mouse_y):
                self.selected_tower = None
                self.selected_plot = pt
                return

        for en in self.__enemies.get():
            if en.enemy_clicked(mouse_x, mouse_y):
                en.selected_enemy = en
                self.selected_plot = None
                return

        # if the button is clicked, get the button response.
        # and keep selecting the tower/plot.
        if self.__menu is not None:
            for btn in self.__menu.buttons:
                if btn.clicked(mouse_x, mouse_y):
                    self.selected_button = btn
            if self.selected_button is None:
                self.selected_tower = None
                self.selected_plot = None
        # menu btn
        for btn in self.__main_menu.buttons:
            if btn.clicked(mouse_x, mouse_y):
                self.selected_button = btn

    def call_menu(self):
        if self.selected_tower is not None:
            x, y = self.selected_tower.rect.center
            self.__menu = UpgradeMenu(x, y)
        elif self.selected_plot is not None:
            x, y = self.selected_plot.rect.center
            self.__menu = BuildMenu2(x, y)
        else:
            self.__menu = None

    def enemies_advance(self):
        self.__enemies.advance(self)

    @property
    def enemies(self):
        return self.__enemies

    @property
    def towers(self):
        return self.__towers

    @property
    def menu(self):
        return self.__menu

    @menu.setter
    def menu(self, new_menu):
        self.__menu = new_menu

    @property
    def plots(self):
        return self.__plots












